import React, { createContext, useContext, useReducer } from 'react';

const StudentContext = createContext();

const initialState = {
    students: [],
};

const studentReducer = (state, action) => {

    switch (action.type) {
        case 'SET_STUDENTS':
            return { ...state, students: action.payload };
        case 'ADD_STUDENT':
            return { ...state, students: [...state.students, action.payload] };
        case 'UPDATE_STUDENT':
            // Assuming action.payload contains the updated student object
            const updatedStudents = state.students.map((student) =>
                student.id === action.payload.id ? action.payload : student
            );
            return { ...state, students: updatedStudents };
        case 'DELETE_STUDENT':
            // Assuming action.payload contains the id of the student to be deleted
            const filteredStudents = state.students.filter((student) => student.id !== action.payload);
            return { ...state, students: filteredStudents };
        default:
            return state;
    }
};

const StudentProvider = ({ children }) => {
    const [state, dispatch] = useReducer(studentReducer, initialState);

    return (
        <StudentContext.Provider value={{ state, dispatch }}>
            {children}
        </StudentContext.Provider>
    );
};

const useStudentContext = () => {
    const context = useContext(StudentContext);
    if (!context) {
        throw new Error('useStudentContext must be used within a StudentProvider');
    }
    return context;
};

export { StudentProvider, useStudentContext };
