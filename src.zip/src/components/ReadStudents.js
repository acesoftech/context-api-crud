import React, { useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useStudentContext } from '../context/StudentContext';

const ReadStudents = () => {
    const { state, dispatch } = useStudentContext();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('https://www.phpkolkata.in/rest-api/crud/fetch.php');
                dispatch({ type: 'SET_STUDENTS', payload: response.data });
            } catch (error) {
                // Handle error, show an error message
            }
        };

        fetchData();
    }, [dispatch]);

    const handleDelete = async (id) => {
        try {
            await axios.delete(`https://www.phpkolkata.in/rest-api/crud/delete.php?id=${id}`);
            // Refetch data after deletion
            const response = await axios.get('https://www.phpkolkata.in/rest-api/crud/fetch.php');
            dispatch({ type: 'SET_STUDENTS', payload: response.data });
        } catch (error) {
            // Handle error, show an error message
        }
    };

    return (
        <div>
            <h2 style={{ background: 'black', color: 'white', padding: '10px' }}>Read Students</h2>
            <table className="table">
                <thead style={{ background: 'black', color: 'white' }}>
                    <tr>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {state.students.map((student) => (
                        <tr key={student.id}>
                            <td>{student.first_name}</td>
                            <td>{student.last_name}</td>
                            <td>{student.email}</td>
                            <td>
                                <button
                                    onClick={() => handleDelete(student.id)}
                                    className="btn btn-danger"
                                >
                                    Delete
                                </button>
                                <Link
                                    to={`/edit/${student.id}`}
                                    className="btn btn-success ms-2"
                                >
                                    Edit
                                </Link>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ReadStudents;
