// src/components/DeleteStudent.js
import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useStudentContext } from '../context/StudentContext';

const DeleteStudent = () => {
    const { id } = useParams();
    const { state, dispatch } = useStudentContext();
    const navigate = useNavigate();

    useEffect(() => {
        const student = state.students.find((s) => s.id === parseInt(id, 10));
        if (!student) {
           // navigate('/read');
        }
    }, [id, state.students, navigate]);

    const handleDelete = async () => {
        try {
            await axios.get(`https://tutorialrays.000webhostapp.com/crud/delete.php?id=${id}`);
            dispatch({ type: 'SET_STUDENTS', payload: state.students.filter((s) => s.id !== parseInt(id, 10)) });
            // Handle success, redirect or show a success message
        } catch (error) {
            // Handle error, show an error message
        }
    };

    return (
        <div>
            <h2>Delete Student</h2>
            <p>Are you sure you want to delete this student?</p>
            <button onClick={handleDelete}>Delete</button>
        </div>
    );
};

export default DeleteStudent;


