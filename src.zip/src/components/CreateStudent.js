import React, { useState } from 'react';
import axios from 'axios';
import { useStudentContext } from '../context/StudentContext';

const CreateStudent = () => {
    const { dispatch } = useStudentContext();
    const [formData, setFormData] = useState({
        first_name: '',
        last_name: '',
        email: '',
        password: '',
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('https://www.phpkolkata.in/rest-api/crud/create.php', formData);
            dispatch({ type: 'ADD_STUDENT', payload: response.data });
            // Handle success, redirect or show a success message
        } catch (error) {
            // Handle error, show an error message
            console.log(error);
        }
    };

    return (
        <div className="container mt-5">
            <h2>Create Student</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="first_name" className="form-label">
                        First Name:
                        <input
                            type="text"
                            id="first_name"
                            name="first_name"
                            value={formData.first_name}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </label>
                </div>
                <div className="mb-3">
                    <label htmlFor="last_name" className="form-label">
                        Last Name:
                        <input
                            type="text"
                            id="last_name"
                            name="last_name"
                            value={formData.last_name}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </label>
                </div>
                <div className="mb-3">
                    <label htmlFor="email" className="form-label">
                        Email:
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </label>
                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">
                        Password:
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </label>
                </div>
                <button type="submit" className="btn btn-primary">
                    Create
                </button>
            </form>
        </div>
    );
};

export default CreateStudent;
