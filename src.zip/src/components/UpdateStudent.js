import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useStudentContext } from '../context/StudentContext';

const UpdateStudent = () => {
    const { id } = useParams();
    const { state, dispatch } = useStudentContext();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        first_name: '',
        last_name: '',
        email: '',
    });

    useEffect(() => {
        const fetchStudentData = async () => {
            try {
                const response = await axios.get(`https://phpkolkata.in/rest-api/crud/readSingle.php?id=${id}`);
                const studentData = response.data;
                setFormData({
                    first_name: studentData.first_name,
                    last_name: studentData.last_name,
                    email: studentData.email,
                });
            } catch (error) {
                console.error('Error fetching student data:', error);
            }
        };

        fetchStudentData();
    }, [id]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            await axios.post(`https://www.phpkolkata.in/rest-api/crud/update.php?id=${id}`, formData);
            dispatch({ type: 'SET_STUDENTS', payload: [...state.students, formData] });

            // Redirect to home page after successful update
            navigate('/'); // Replace '/' with the actual path to your home page
        } catch (error) {
            // Handle error, show an error message
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="mb-4">Update Student</h2>
            <form onSubmit={handleSubmit} className="needs-validation" noValidate>
                <div className="mb-3">
                    <label htmlFor="first_name" className="form-label">
                        First Name:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="first_name"
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleChange}
                        required
                    />
                    <div className="invalid-feedback">Please provide a valid first name.</div>
                </div>

                <div className="mb-3">
                    <label htmlFor="last_name" className="form-label">
                        Last Name:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="last_name"
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleChange}
                        required
                    />
                    <div className="invalid-feedback">Please provide a valid last name.</div>
                </div>

                <div className="mb-3">
                    <label htmlFor="email" className="form-label">
                        Email:
                    </label>
                    <input
                        type="email"
                        className="form-control"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    <div className="invalid-feedback">Please provide a valid email address.</div>
                </div>

                <button type="submit" className="btn btn-primary">
                    Update
                </button>
            </form>
        </div>
    );
};

export default UpdateStudent;
